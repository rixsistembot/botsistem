[
{
"Verification code" : 1234,
"Status" : False,
"Message" : "Please refresh your browser"
}
,
{
"Verification code" : 1278,
"Status" : False,
"Message" : "Please refresh your browser"
}
,
{
"Verification code" : 7892,
"Status" : False,
"Message" : "Please refresh your browser"
}
,
{
"Verification code" : 6274,
"Status" : False,
"Message" : "Please refresh your browser"
}
,
{
"Verification code" : 8810,
"Status" : False,
"Message" : "Please refresh your browser"
}
,
{
"Verification code" : 3670,
"Status" :True,
"Message" : "Send this code to WhatsApp bot"
}
,
{
"Verification code" : 9093,
"Status" :True,
"Message" : "Send this code to WhatsApp bot"
}
,
{
"Verification code" : 6389,
"Status" :True,
"Message" : "Send this code to WhatsApp bot"
}
,
{
"Verification code" : 4629,
"Status" :True,
"Message" : "Send this code to WhatsApp bot"
}
,
{
"Verification code" : 1073,
"Status" :True,
"Message" : "Send this code to WhatsApp bot"
}
]
